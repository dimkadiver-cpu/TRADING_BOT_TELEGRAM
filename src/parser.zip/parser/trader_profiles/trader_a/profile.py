"""Trader A profile parser."""

from __future__ import annotations

import json
from pathlib import Path
import re
from typing import Any

from src.parser.trader_profiles.base import ParserContext, TraderParseResult
from src.parser.trader_profiles.common_utils import extract_telegram_links, normalize_text, split_lines

_RULES_PATH = Path(__file__).resolve().parent / "parsing_rules.json"
_SYMBOL_RE = re.compile(r"\b[A-Z0-9]{1,24}(?:USDT|USDC|USD|BTC|ETH)(?:\.P)?\b")
_LINK_ID_RE = re.compile(r"(?:https?://)?t\.me/(?:c/\d+|[A-Za-z0-9_]+)/(?P<id>\d+)", re.IGNORECASE)
_RESULT_R_RE = re.compile(r"\b[A-Z]{2,20}(?:USDT|USDC|USD|BTC|ETH)?\s*[-:=]\s*[+-]?\d+(?:[.,]\d+)?\s*R{1,2}\b", re.IGNORECASE)
_RESULT_R_CAPTURE_RE = re.compile(
    r"\b(?P<symbol>[A-Z]{2,20}(?:USDT|USDC|USD|BTC|ETH)?)\s*[-:=]\s*(?P<value>[+-]?\d+(?:[.,]\d+)?)\s*R{1,2}\b",
    re.IGNORECASE,
)
_PERCENT_RE = re.compile(r"\b(?P<value>\d{1,3}(?:[.,]\d+)?)%")
_TP_INDEX_RE = re.compile(r"\btp(?P<index>\d+)\b", re.IGNORECASE)
_STOP_LEVEL_RE = re.compile(r"(?:move\s*(?:sl|stop)\s*(?:to)?|sl|stop)\s*[:=@-]?\s*(?P<value>\d+(?:[.,]\d+)?)", re.IGNORECASE)
_ENTRY_VALUE_RE = re.compile(
    r"(?:entry|entries|\u0432\u0445\u043e\u0434(?:\s+\u0441\s+\u0442\u0435\u043a\u0443\u0449\u0438\u0445|\s+\u043b\u0438\u043c\u0438\u0442\u043a\u043e\u0439|\s+\u043b\u0438\u043c\u0438\u0442\u043d\u044b\u043c\s+\u043e\u0440\u0434\u0435\u0440\u043e\u043c)?)\s*[:=@-]?\s*(?P<value>\d[\d\s]*(?:[.,]\d+)?)",
    re.IGNORECASE,
)
_STOP_LOSS_VALUE_RE = re.compile(r"(?:\bsl\b|stop|\u0441\u0442\u043e\u043f)\s*[:=@-]?\s*(?P<value>\d[\d\s]*(?:[.,]\d+)?)", re.IGNORECASE)
_TAKE_PROFIT_VALUE_RE = re.compile(r"\btp(?:\d+)?\s*[:=@-]?\s*(?P<value>\d[\d\s]*(?:[.,]\d+)?)", re.IGNORECASE)
_AVERAGING_VALUE_RE = re.compile(r"(?:averaging|\u0443\u0441\u0440\u0435\u0434\u043d\u0435\u043d\u0438\u0435)\s*[:=@-]?\s*(?P<value>\d[\d\s]*(?:[.,]\d+)?)", re.IGNORECASE)
_STOP_TO_TP1_RE = re.compile(
    r"(?:\u0441\u0442\u043e\u043f\s+\u043d\u0430\s+(?:1|\u043f\u0435\u0440\u0432\u044b\u0439)\s+\u0442\u0435\u0439\u043a|\u0441\u0442\u043e\u043f\s+\u043d\u0430\s+tp1)",
    re.IGNORECASE,
)
_TP2_HIT_RE = re.compile(
    r"(?:\u0434\u043e\u0448\u043b\u0438\s+\u0434\u043e\s+2[-\s]?(?:\u0445|x)?\s+\u0442\u0435\u0439\u043a\u043e\u0432|2[-\s]?(?:\u0445|x)?\s+\u0442\u0435\u0439\u043a)",
    re.IGNORECASE,
)
_TP1_HIT_RE = re.compile(r"(?:1\s+\u0442\u0435\u0439\u043a|\u043f\u0435\u0440\u0432\u044b\u0439\s+\u0442\u0435\u0439\u043a)", re.IGNORECASE)
_ENTRY_AB_VALUE_RE = re.compile(
    r"(?:^|\n)\s*(?:[-\u2014\u2022]\s*)?(?:\u0432\u0445\u043e\u0434\s*)?(?:\((?P<label_paren>[ab\u0430\u0431])\)|(?P<label>[ab\u0430\u0431]))(?:\s*\((?P<qual>[^)]*)\))?\s*[:=@-]\s*(?P<value>\d[\d\s]*(?:[.,]\d+)?)",
    re.IGNORECASE,
)

_DEFAULT_CLASSIFICATION_MARKERS: dict[str, tuple[str, ...]] = {
    "new_signal_strong": (
        "long",
        "short",
        "\u043b\u043e\u043d\u0433",
        "\u0448\u043e\u0440\u0442",
        "entry",
        "\u0432\u0445\u043e\u0434",
        "\u0432\u0445\u043e\u0434 \u0441 \u0442\u0435\u043a\u0443\u0449\u0438\u0445",
        "sl:",
        "tp1:",
        "tp2:",
        "tp3:",
        "tp:",
    ),
    "update_strong": (
        "\u0441\u0442\u043e\u043f \u0432 \u0431\u0443",
        "\u0441\u0442\u043e\u043f \u043d\u0430 1 \u0442\u0435\u0439\u043a",
        "\u0441\u0442\u043e\u043f \u043d\u0430 \u043f\u0435\u0440\u0432\u044b\u0439 \u0442\u0435\u0439\u043a",
        "\u043e\u0441\u0442\u0430\u0442\u043e\u043a \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0435\u0439 \u0446\u0435\u043d\u0435",
        "\u0434\u043e\u0448\u043b\u0438 \u0434\u043e 2-\u0445 \u0442\u0435\u0439\u043a\u043e\u0432",
        "move stop",
        "close all",
        "\u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u0432\u0441\u0435 \u043f\u043e\u0437\u0438\u0446\u0438\u0438",
        "\u0437\u0430\u0444\u0438\u043a\u0441\u0438\u0440\u0443\u044e \u0432\u0441\u0435 \u0441\u0432\u043e\u0438 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
    ),
    "setup_incomplete": (
        "\u0442\u0435\u0439\u043a\u0438 \u043f\u043e\u0437\u0436\u0435",
        "\u0438\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e \u0442\u0435\u0439\u043a\u0430\u0445 \u043f\u043e\u0437\u0436\u0435",
        "entry only",
        "sl later",
        "tp later",
    ),
}

_DEFAULT_INTENT_MARKERS: dict[str, tuple[str, ...]] = {
    "U_MOVE_STOP_TO_BE": (
        "move stop to be",
        "stop to breakeven",
        "stop to entry",
        "\u0441\u0442\u043e\u043f \u0432 \u0431\u0443",
        "\u0441\u0442\u043e\u043f\u044b \u0432 \u0431\u0443",
        "\u0441\u0442\u043e\u043f \u0432 \u0431\u0435\u0437\u0443\u0431\u044b\u0442\u043e\u043a",
    ),
    "U_MOVE_STOP": (
        "move stop",
        "move sl",
        "\u0441\u0442\u043e\u043f \u043d\u0430 1 \u0442\u0435\u0439\u043a",
        "\u0441\u0442\u043e\u043f \u043d\u0430 \u043f\u0435\u0440\u0432\u044b\u0439 \u0442\u0435\u0439\u043a",
        "\u0441\u0442\u043e\u043f \u043d\u0430 tp1",
    ),
    "U_CANCEL_PENDING_ORDERS": (
        "cancel pending",
        "cancel limit",
        "\u0443\u0431\u0438\u0440\u0430\u0435\u043c \u043b\u0438\u043c\u0438\u0442\u043a\u0438",
        "\u0443\u0431\u0435\u0440\u0435\u043c \u043b\u0438\u043c\u0438\u0442\u043a\u0438",
        "\u0441\u043d\u0438\u043c\u0430\u0435\u043c \u043b\u0438\u043c\u0438\u0442\u043a\u0438",
        "\u0441\u043d\u044f\u0442\u044c \u043b\u0438\u043c\u0438\u0442\u043a\u0438",
        "\u043b\u0438\u043c\u0438\u0442\u043a\u0438 \u0443\u0431\u0438\u0440\u0430\u0435\u043c",
        "\u043e\u0442\u043c\u0435\u043d\u044f\u0435\u043c \u043b\u0438\u043c\u0438\u0442\u043a\u0438",
        "\u0441\u043d\u044f\u0442\u044c \u0432\u0441\u0435 \u043b\u0438\u043c\u0438\u0442\u043d\u044b\u0435 \u043e\u0440\u0434\u0435\u0440\u0430",
        "\u0441\u043d\u044f\u0442\u044c \u043b\u0438\u043c\u0438\u0442\u043d\u044b\u0435 \u043e\u0440\u0434\u0435\u0440\u0430",
        "\u0441\u043d\u044f\u0442\u044c \u043e\u0440\u0434\u0435\u0440\u0430",
    ),
    "U_CLOSE_FULL": (
        "close all",
        "close full",
        "\u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u0432\u0441\u0435 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
        "\u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u0432\u0441\u0435 \u043f\u043e\u0437\u0438\u0446\u0438\u0438",
        "\u0437\u0430\u0444\u0438\u043a\u0441\u0438\u0440\u0443\u044e \u0432\u0441\u0435 \u0441\u0432\u043e\u0438 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
        "\u043e\u0441\u0442\u0430\u0442\u043e\u043a \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0435\u0439 \u0446\u0435\u043d\u0435",
        "\u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
        "\u0432\u0441\u0435 \u043b\u043e\u043d\u0433\u0438 \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
        "\u0432\u0441\u0435 \u0448\u043e\u0440\u0442\u044b \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
        "\u0437\u0430\u0444\u0438\u043a\u0441\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0432\u0441\u0435 \u0448\u043e\u0440\u0442\u044b",
        "\u0437\u0430\u0444\u0438\u043a\u0441\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0432\u0441\u0435 \u043b\u043e\u043d\u0433\u0438",
    ),
    "U_CLOSE_PARTIAL": ("partial close", "close half", "\u0447\u0430\u0441\u0442\u0438\u0447\u043d\u043e", "\u043f\u043e\u043b\u043e\u0432\u0438\u043d\u0443"),
    "U_TP_HIT": (
        "tp hit",
        "tp1 hit",
        "\u0442\u0435\u0439\u043a \u0432\u0437\u044f\u0442",
        "\u0434\u043e\u0448\u043b\u0438 \u0434\u043e 2-\u0445 \u0442\u0435\u0439\u043a\u043e\u0432",
        "1 \u0442\u0435\u0439\u043a",
    ),
    "U_STOP_HIT": ("stop hit", "stopped out", "\u0432\u044b\u0431\u0438\u043b\u043e \u043f\u043e \u0441\u0442\u043e\u043f\u0443"),
    "U_MARK_FILLED": ("entry filled", "filled", "\u0432\u0445\u043e\u0434 \u0438\u0441\u043f\u043e\u043b\u043d\u0435\u043d"),
    "U_REPORT_FINAL_RESULT": ("final result", "results", "\u0438\u0442\u043e\u0433", "\u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u044b"),
}


class TraderAProfileParser:
    trader_code = "trader_a"

    def __init__(self, rules_path: Path | None = None) -> None:
        self._rules_path = rules_path or _RULES_PATH
        self._rules = self._load_rules(self._rules_path)

    def parse_message(self, text: str, context: ParserContext) -> TraderParseResult:
        prepared = self._preprocess(text=text, context=context)
        target_refs = self._extract_targets(prepared=prepared, context=context)
        message_type = self._classify_message(prepared=prepared, context=context, target_refs=target_refs)
        intents = self._extract_intents(
            prepared=prepared,
            context=context,
            message_type=message_type,
            target_refs=target_refs,
        )
        if message_type == "UNCLASSIFIED" and "U_REPORT_FINAL_RESULT" in intents:
            if target_refs and any(intent in intents for intent in ("U_CLOSE_FULL", "U_CLOSE_PARTIAL", "U_CANCEL_PENDING_ORDERS", "U_MOVE_STOP_TO_BE", "U_MOVE_STOP")):
                message_type = "UPDATE"
            else:
                message_type = "INFO_ONLY"
        if message_type == "UNCLASSIFIED" and "U_CANCEL_PENDING_ORDERS" in intents and target_refs:
            message_type = "UPDATE"
        reported_results = self._extract_reported_results(prepared=prepared, context=context, intents=intents)
        entities = self._extract_entities(
            prepared=prepared,
            context=context,
            intents=intents,
            reported_results=reported_results,
        )
        warnings = self._build_warnings(
            prepared=prepared,
            context=context,
            message_type=message_type,
            intents=intents,
            target_refs=target_refs,
        )
        confidence = self._estimate_confidence(
            prepared=prepared,
            context=context,
            message_type=message_type,
            intents=intents,
            warnings=warnings,
        )
        return TraderParseResult(
            message_type=message_type,
            intents=intents,
            entities=entities,
            target_refs=target_refs,
            reported_results=reported_results,
            warnings=warnings,
            confidence=confidence,
        )

    def _preprocess(self, *, text: str, context: ParserContext) -> dict[str, Any]:
        raw_text = text or context.raw_text
        return {
            "raw_text": raw_text,
            "normalized_text": normalize_text(raw_text),
            "lines": split_lines(raw_text),
        }

    def _classify_message(
        self,
        *,
        prepared: dict[str, Any],
        context: ParserContext,
        target_refs: list[dict[str, Any]],
    ) -> str:
        normalized = str(prepared.get("normalized_text") or "")
        raw_text = str(prepared.get("raw_text") or "")
        has_target = bool(target_refs)
        classification = self._rules.get("classification_markers") if isinstance(self._rules, dict) else {}
        new_markers = _merge_markers(_class_markers(classification, "new_signal"), _DEFAULT_CLASSIFICATION_MARKERS["new_signal_strong"])
        update_markers = _merge_markers(_class_markers(classification, "update"), _DEFAULT_CLASSIFICATION_MARKERS["update_strong"])
        incomplete_markers = _merge_markers(
            classification.get("setup_incomplete") if isinstance(classification, dict) else None,
            _DEFAULT_CLASSIFICATION_MARKERS["setup_incomplete"],
        )

        if _contains_any(normalized, tuple(_ignore_markers(self._rules))):
            return "INFO_ONLY"

        has_symbol = _extract_signal_symbol(raw_text) is not None
        has_direction = _contains_any(normalized, ("long", "short", "buy", "sell", "\u043b\u043e\u043d\u0433", "\u0448\u043e\u0440\u0442"))
        has_entry = _contains_any(normalized, ("entry", "entries", "\u0432\u0445\u043e\u0434", "\u0432\u0445\u043e\u0434 \u0441 \u0442\u0435\u043a\u0443\u0449\u0438\u0445")) or bool(_extract_signal_entry_levels(raw_text))
        has_stop = _contains_any(normalized, ("stop", "sl", "sl:", "\u0441\u0442\u043e\u043f"))
        has_tp = bool(re.search(r"\btp\d+\b", raw_text, re.IGNORECASE)) or _contains_any(
            normalized,
            (
                "tp1:",
                "tp2:",
                "tp3:",
                "tp:",
                "take profit",
                "target",
                "1 \u0442\u0435\u0439\u043a",
                "\u043f\u0435\u0440\u0432\u044b\u0439 \u0442\u0435\u0439\u043a",
            ),
        )
        setup_parts = sum(1 for value in (has_symbol, has_direction, has_entry, has_stop, has_tp) if value)

        # Full setup has highest priority, even if message is a reply.
        if has_symbol and has_direction and has_entry and has_stop and has_tp and (_contains_any(normalized, tuple(new_markers)) or has_entry):
            return "NEW_SIGNAL"
        if setup_parts >= 2 and _contains_any(normalized, tuple(incomplete_markers)):
            return "SETUP_INCOMPLETE"
        if _contains_any(
            normalized,
            (
                "\u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u0432\u0441\u0435 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
                "\u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u0432\u0441\u0435 \u043f\u043e\u0437\u0438\u0446\u0438\u0438",
                "\u0437\u0430\u0444\u0438\u043a\u0441\u0438\u0440\u0443\u044e \u0432\u0441\u0435 \u0441\u0432\u043e\u0438 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
                "\u0432\u0441\u0435 \u043b\u043e\u043d\u0433\u0438 \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
                "\u0432\u0441\u0435 \u0448\u043e\u0440\u0442\u044b \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0438\u043c",
                "\u0437\u0430\u0444\u0438\u043a\u0441\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0432\u0441\u0435 \u0448\u043e\u0440\u0442\u044b",
                "\u0437\u0430\u0444\u0438\u043a\u0441\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0432\u0441\u0435 \u043b\u043e\u043d\u0433\u0438",
            ),
        ):
            return "UPDATE"
        if has_target and _contains_any(normalized, tuple(update_markers)):
            return "UPDATE"
        if has_target and _contains_any(
            normalized,
            (
                "move",
                "close",
                "cancel",
                "filled",
                "tp hit",
                "tp1 hit",
                "target hit",
                "stop hit",
                "stopped out",
                "stop to be",
                "\u0442\u0435\u0439\u043a \u0432\u0437\u044f\u0442",
                "\u0432\u044b\u0431\u0438\u043b\u043e \u043f\u043e \u0441\u0442\u043e\u043f\u0443",
                "\u0441\u0442\u043e\u043f \u0432 \u0431\u0443",
                "\u0441\u0442\u043e\u043f\u044b \u0432 \u0431\u0443",
                "\u0441\u0442\u043e\u043f \u043d\u0430 1 \u0442\u0435\u0439\u043a",
                "\u043e\u0441\u0442\u0430\u0442\u043e\u043a \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e \u043f\u043e \u0442\u0435\u043a\u0443\u0449\u0435\u0439 \u0446\u0435\u043d\u0435",
                "\u0434\u043e\u0448\u043b\u0438 \u0434\u043e 2-\u0445 \u0442\u0435\u0439\u043a\u043e\u0432",
            ),
        ):
            return "UPDATE"
        _ = context
        return "UNCLASSIFIED"

    def _extract_targets(self, *, prepared: dict[str, Any], context: ParserContext) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        seen: set[tuple[str, str]] = set()

        def _append(kind: str, ref: object) -> None:
            key = (kind, str(ref))
            if key in seen:
                return
            seen.add(key)
            out.append({"kind": kind, "ref": ref})

        if context.reply_to_message_id is not None:
            _append("reply", int(context.reply_to_message_id))

        raw_text = str(prepared.get("raw_text") or "")
        for link in list(context.extracted_links) + extract_telegram_links(raw_text):
            _append("telegram_link", link)
            match = _LINK_ID_RE.search(link)
            if match:
                _append("message_id", int(match.group("id")))
        return out

    def _extract_intents(
        self,
        *,
        prepared: dict[str, Any],
        context: ParserContext,
        message_type: str,
        target_refs: list[dict[str, Any]],
    ) -> list[str]:
        normalized = str(prepared.get("normalized_text") or "")
        raw_text = str(prepared.get("raw_text") or "")
        marker_map = self._rules.get("intent_markers") if isinstance(self._rules, dict) else {}
        if not isinstance(marker_map, dict):
            marker_map = {}

        intents: list[str] = []
        has_target = bool(target_refs)
        if _contains_any(normalized, tuple(_ignore_markers(self._rules))):
            _ = context
            return []
        if message_type == "NEW_SIGNAL":
            intents.append("NS_CREATE_SIGNAL")

        move_to_be_markers = _merge_markers(_strong_only(marker_map.get("U_MOVE_STOP_TO_BE")), _DEFAULT_INTENT_MARKERS["U_MOVE_STOP_TO_BE"])
        move_markers = _merge_markers(_strong_only(marker_map.get("U_MOVE_STOP")), _DEFAULT_INTENT_MARKERS["U_MOVE_STOP"])
        cancel_markers = _merge_markers(marker_map.get("U_CANCEL_PENDING_ORDERS"), _DEFAULT_INTENT_MARKERS["U_CANCEL_PENDING_ORDERS"])
        strong_move_without_target = _contains_any(normalized, tuple(move_to_be_markers)) or _contains_any(normalized, tuple(move_markers))
        strong_cancel_without_target = _contains_any(normalized, tuple(cancel_markers))

        allow_update_intents = message_type == "UPDATE" or has_target or strong_move_without_target or strong_cancel_without_target
        if allow_update_intents:
            move_markers = _merge_markers(marker_map.get("U_MOVE_STOP"), _DEFAULT_INTENT_MARKERS["U_MOVE_STOP"])
            close_partial_markers = _merge_markers(marker_map.get("U_CLOSE_PARTIAL"), _DEFAULT_INTENT_MARKERS["U_CLOSE_PARTIAL"])
            close_full_markers = _merge_markers(marker_map.get("U_CLOSE_FULL"), _DEFAULT_INTENT_MARKERS["U_CLOSE_FULL"])
            tp_hit_markers = _merge_markers(_strong_only(marker_map.get("U_TP_HIT")), _DEFAULT_INTENT_MARKERS["U_TP_HIT"])
            stop_hit_markers = _merge_markers(_strong_only(marker_map.get("U_STOP_HIT")), _DEFAULT_INTENT_MARKERS["U_STOP_HIT"])
            filled_markers = _merge_markers(marker_map.get("U_MARK_FILLED"), _DEFAULT_INTENT_MARKERS["U_MARK_FILLED"])

            if message_type != "NEW_SIGNAL":
                if _contains_any(normalized, tuple(move_to_be_markers)):
                    intents.append("U_MOVE_STOP_TO_BE")
                    intents.append("U_MOVE_STOP")
                elif _contains_any(normalized, tuple(move_markers)):
                    intents.append("U_MOVE_STOP")

            if _contains_any(normalized, tuple(cancel_markers)):
                intents.append("U_CANCEL_PENDING_ORDERS")
            if _contains_any(normalized, tuple(close_partial_markers)):
                intents.append("U_CLOSE_PARTIAL")
            elif _contains_any(normalized, tuple(close_full_markers)):
                intents.append("U_CLOSE_FULL")

            stop_to_tp_context = bool(_STOP_TO_TP1_RE.search(raw_text))
            if message_type != "NEW_SIGNAL" and not stop_to_tp_context and _contains_any(normalized, tuple(tp_hit_markers)):
                intents.append("U_TP_HIT")
            if message_type != "NEW_SIGNAL" and _contains_any(normalized, tuple(stop_hit_markers)):
                intents.append("U_STOP_HIT")
            if _contains_any(normalized, tuple(filled_markers)):
                intents.append("U_MARK_FILLED")

        report_markers = _merge_markers(marker_map.get("U_REPORT_FINAL_RESULT"), _DEFAULT_INTENT_MARKERS["U_REPORT_FINAL_RESULT"])
        if _RESULT_R_RE.search(raw_text):
            intents.append("U_REPORT_FINAL_RESULT")
        elif _contains_any(normalized, tuple(report_markers)) and _contains_any(normalized, ("final result", "result summary", "\u0438\u0442\u043e\u0433", "\u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u044b")):
            intents.append("U_REPORT_FINAL_RESULT")

        if "U_CLOSE_FULL" in intents and "U_REPORT_FINAL_RESULT" in intents:
            intents = [value for value in intents if value not in ("U_MOVE_STOP_TO_BE", "U_MOVE_STOP")]

        _ = context
        return _unique(intents)

    def _extract_entities(
        self,
        *,
        prepared: dict[str, Any],
        context: ParserContext,
        intents: list[str],
        reported_results: list[dict[str, Any]],
    ) -> dict[str, Any]:
        normalized = str(prepared.get("normalized_text") or "")
        raw_text = str(prepared.get("raw_text") or "")
        entities: dict[str, Any] = {}

        if "NS_CREATE_SIGNAL" in intents:
            entities["symbol"] = _extract_signal_symbol(raw_text)
            entities["side"] = _extract_signal_side(normalized)
            entities["entry"] = _extract_signal_entry_levels(raw_text)
            entities["stop_loss"] = _extract_signal_stop_loss(raw_text)
            entities["take_profits"] = _extract_signal_take_profits(raw_text)
            averaging = _extract_signal_averaging(raw_text)
            if averaging is not None:
                entities["averaging"] = averaging

        if "U_MOVE_STOP_TO_BE" in intents:
            entities["new_stop_level"] = "ENTRY"
        elif "U_MOVE_STOP" in intents:
            stop_level = _extract_stop_level(raw_text)
            if stop_level is not None:
                entities["new_stop_level"] = stop_level
        if "U_CLOSE_FULL" in intents:
            if _contains_any(normalized, ("\u0432\u0441\u0435 \u043b\u043e\u043d\u0433\u0438", "all longs", "\u043b\u043e\u043d\u0433\u0438")):
                entities["close_scope"] = "ALL_LONGS"
            elif _contains_any(normalized, ("\u0432\u0441\u0435 \u0448\u043e\u0440\u0442\u044b", "all shorts", "\u0448\u043e\u0440\u0442\u044b")):
                entities["close_scope"] = "ALL_SHORTS"
            else:
                entities["close_scope"] = "FULL"
        elif "U_CLOSE_PARTIAL" in intents:
            entities["close_scope"] = "PARTIAL"
            close_fraction = _extract_close_fraction(raw_text=raw_text, normalized_text=normalized)
            if close_fraction is not None:
                entities["close_fraction"] = close_fraction
        if "U_STOP_HIT" in intents:
            entities["hit_target"] = "STOP"
        elif "U_TP_HIT" in intents:
            entities["hit_target"] = _extract_hit_target(raw_text) or "TP"
        if "U_MARK_FILLED" in intents:
            entities["fill_state"] = "FILLED"
        if "U_CANCEL_PENDING_ORDERS" in intents:
            entities["cancel_scope"] = "ALL_PENDING_ENTRIES"
        if "U_REPORT_FINAL_RESULT" in intents:
            entities["result_mode"] = "R_MULTIPLE" if reported_results else "TEXT_SUMMARY"
        _ = context
        return entities

    def _extract_reported_results(
        self,
        *,
        prepared: dict[str, Any],
        context: ParserContext,
        intents: list[str],
    ) -> list[dict[str, Any]]:
        raw_text = str(prepared.get("raw_text") or "")
        if "U_REPORT_FINAL_RESULT" not in intents and not _RESULT_R_RE.search(raw_text):
            _ = context
            return []
        patterns = self._rules.get("result_patterns") if isinstance(self._rules, dict) else {}
        capture_patterns = _as_str_list(patterns.get("r_multiple")) if isinstance(patterns, dict) else []
        regexes: list[re.Pattern[str]] = []
        for pattern in capture_patterns:
            try:
                regexes.append(re.compile(pattern, re.IGNORECASE))
            except re.error:
                continue
        if not regexes:
            regexes = [_RESULT_R_CAPTURE_RE]

        out: list[dict[str, Any]] = []
        seen: set[tuple[str, float]] = set()
        for regex in regexes:
            for match in regex.finditer(raw_text):
                symbol = match.groupdict().get("symbol")
                value_raw = match.groupdict().get("value")
                if not symbol or not value_raw:
                    continue
                value = _to_float(value_raw)
                if value is None:
                    continue
                key = (symbol.upper(), value)
                if key in seen:
                    continue
                seen.add(key)
                out.append({"symbol": symbol.upper(), "value": value, "unit": "R"})
        _ = context
        return out

    def _build_warnings(
        self,
        *,
        prepared: dict[str, Any],
        context: ParserContext,
        message_type: str,
        intents: list[str],
        target_refs: list[dict[str, Any]],
    ) -> list[str]:
        warnings: list[str] = []
        normalized = str(prepared.get("normalized_text") or "")
        classification = self._rules.get("classification_markers") if isinstance(self._rules, dict) else {}
        update_markers = _merge_markers(_class_markers(classification if isinstance(classification, dict) else {}, "update"), _DEFAULT_CLASSIFICATION_MARKERS["update_strong"])
        has_target = bool(target_refs)
        has_update_language = _contains_any(normalized, tuple(update_markers)) or _contains_any(
            normalized,
            ("move", "close", "cancel", "filled", "tp hit", "stop hit", "stopped out", "\u0441\u0442\u043e\u043f \u0432 \u0431\u0443", "\u0441\u0442\u043e\u043f\u044b \u0432 \u0431\u0443"),
        )
        has_update_intent = any(intent.startswith("U_") and intent != "U_REPORT_FINAL_RESULT" for intent in intents)

        if not has_target and (has_update_language or has_update_intent):
            if message_type == "UPDATE":
                warnings.append("trader_a_update_missing_target")
            else:
                warnings.append("trader_a_ambiguous_update_without_target")
        _ = context
        return warnings

    def _estimate_confidence(
        self,
        *,
        prepared: dict[str, Any],
        context: ParserContext,
        message_type: str,
        intents: list[str],
        warnings: list[str],
    ) -> float:
        _ = (prepared, context, intents)
        if message_type == "NEW_SIGNAL":
            return 0.75
        if message_type == "UPDATE":
            return 0.7 if not warnings else 0.55
        if message_type == "SETUP_INCOMPLETE":
            return 0.45
        return 0.2

    def _load_rules(self, path: Path) -> dict[str, Any]:
        try:
            with path.open("r", encoding="utf-8") as file:
                data = json.load(file)
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            return {}
        return {}


def _as_str_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item.strip().lower() for item in value if isinstance(item, str) and item.strip()]


def _rule_markers(value: Any) -> list[str]:
    if isinstance(value, list):
        return _as_str_list(value)
    if isinstance(value, dict):
        out: list[str] = []
        for nested in value.values():
            out.extend(_rule_markers(nested))
        return out
    return []


def _merge_markers(value: Any, defaults: tuple[str, ...] | list[str]) -> list[str]:
    merged = list(_rule_markers(value))
    for marker in defaults:
        normalized = str(marker).strip().lower()
        if normalized and normalized not in merged:
            merged.append(normalized)
    return merged


def _class_markers(classification: Any, base: str) -> list[str]:
    if not isinstance(classification, dict):
        return []
    merged: list[str] = []
    for key in (base, f"{base}_strong", f"{base}_weak"):
        merged = _merge_markers(classification.get(key), merged)
    return merged


def _ignore_markers(rules: dict[str, Any]) -> list[str]:
    markers = _rule_markers(rules.get("ignore_markers")) if isinstance(rules, dict) else []
    for marker in (
        "# \u0430\u0434\u043c\u0438\u043d",
        "#\u0430\u0434\u043c\u0438\u043d",
        "\u044d\u0442\u043e \u0430\u0434\u043c\u0438\u043d",
        "\u0441\u0442\u0430\u0440\u0442:",
        "\u0444\u0438\u043d\u0438\u0448:",
        "#admin",
    ):
        value = marker.strip().lower()
        if value and value not in markers:
            markers.append(value)
    return markers


def _strong_only(value: Any) -> Any:
    if isinstance(value, dict):
        return value.get("strong", [])
    return value


def _contains_any(text: str, markers: tuple[str, ...] | list[str]) -> bool:
    lowered = text.lower()
    padded = f" {lowered} "
    for marker in markers:
        probe = (str(marker) if marker is not None else "").strip().lower()
        if not probe:
            continue
        if " " not in probe and len(probe) <= 3 and re.fullmatch(r"[a-z0-9]+", probe):
            if re.search(rf"(?<![A-Za-z0-9_]){re.escape(probe)}(?![A-Za-z0-9_])", lowered, re.IGNORECASE):
                return True
            continue
        if probe in padded:
            return True
    return False


def _unique(values: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _extract_close_fraction(*, raw_text: str, normalized_text: str) -> float | None:
    match = _PERCENT_RE.search(raw_text)
    if match:
        value = _to_float(match.group("value"))
        if value is not None:
            return round(max(0.0, min(1.0, value / 100.0)), 6)
    if _contains_any(normalized_text, ("half", "1/2", "\u043f\u043e\u043b\u043e\u0432\u0438\u043d\u0443", "\u0447\u0430\u0441\u0442\u044c")):
        return 0.5
    return None


def _extract_hit_target(raw_text: str) -> str | None:
    match = _TP_INDEX_RE.search(raw_text)
    if match:
        return f"TP{match.group('index')}"
    if _TP2_HIT_RE.search(raw_text):
        return "TP2"
    if _TP1_HIT_RE.search(raw_text):
        return "TP1"
    return None


def _extract_stop_level(raw_text: str) -> float | str | None:
    if _STOP_TO_TP1_RE.search(raw_text):
        return "TP1"
    match = _STOP_LEVEL_RE.search(raw_text)
    if not match:
        return None
    value_raw = match.group("value")
    value = _to_float(value_raw)
    if value is not None:
        return value
    return value_raw


def _extract_signal_symbol(raw_text: str) -> str | None:
    match = _SYMBOL_RE.search(raw_text.upper())
    if not match:
        return None
    return match.group(0).upper()


def _extract_signal_side(normalized_text: str) -> str | None:
    if _contains_any(normalized_text, ("\u043b\u043e\u043d\u0433", "long", "buy")):
        return "LONG"
    if _contains_any(normalized_text, ("\u0448\u043e\u0440\u0442", "short", "sell")):
        return "SHORT"
    return None


def _extract_signal_entry_levels(raw_text: str) -> list[float]:
    out: list[float] = []
    for match in _ENTRY_VALUE_RE.finditer(raw_text):
        line_start = raw_text.rfind("\n", 0, match.start()) + 1
        line_end = raw_text.find("\n", match.end())
        if line_end == -1:
            line_end = len(raw_text)
        line_text = raw_text[line_start:line_end]
        if "%" in line_text:
            continue
        value = _to_float(match.group("value"))
        if value is None or value in out:
            continue
        out.append(value)
    for match in _ENTRY_AB_VALUE_RE.finditer(raw_text):
        line_start = raw_text.rfind("\n", 0, match.start()) + 1
        line_end = raw_text.find("\n", match.end())
        if line_end == -1:
            line_end = len(raw_text)
        line_text = raw_text[line_start:line_end]
        if "%" in line_text:
            continue
        qual = str(match.groupdict().get("qual") or "").lower()
        label = str(match.groupdict().get("label") or match.groupdict().get("label_paren") or "").lower()
        if label in ("b", "\u0431") and _contains_any(qual, ("\u0443\u0441\u0440\u0435\u0434", "\u0434\u043e\u0431\u043e\u0440", "averag", "top up")):
            continue
        value = _to_float(str(match.group("value")))
        if value is None or value in out:
            continue
        out.append(value)
    # Fallback for noisy unicode bullets/labels: capture explicit A/B entry lines.
    for match in re.finditer(
        r"(?:^|\n)[^\n]*?\b(?P<label>[ab])\b(?P<tail>[^\n:]*)[:=@-]\s*(?P<value>\d[\d\s]*(?:[.,]\d+)?)",
        raw_text,
        re.IGNORECASE,
    ):
        line_start = raw_text.rfind("\n", 0, match.start()) + 1
        line_end = raw_text.find("\n", match.end())
        if line_end == -1:
            line_end = len(raw_text)
        line_text = raw_text[line_start:line_end]
        if "%" in line_text:
            continue
        tail = str(match.groupdict().get("tail") or "").lower()
        label = str(match.groupdict().get("label") or "").lower()
        if label == "b" and _contains_any(tail, ("\u0443\u0441\u0440\u0435\u0434", "\u0434\u043e\u0431\u043e\u0440", "averag", "top up")):
            continue
        value = _to_float(str(match.group("value")))
        if value is None or value in out:
            continue
        out.append(value)
    return out


def _extract_signal_stop_loss(raw_text: str) -> float | None:
    match = _STOP_LOSS_VALUE_RE.search(raw_text)
    if not match:
        return None
    return _to_float(match.group("value"))


def _extract_signal_take_profits(raw_text: str) -> list[float]:
    out: list[float] = []
    for match in _TAKE_PROFIT_VALUE_RE.finditer(raw_text):
        value = _to_float(match.group("value"))
        if value is None or value in out:
            continue
        out.append(value)
    return out


def _extract_signal_averaging(raw_text: str) -> float | None:
    match = _AVERAGING_VALUE_RE.search(raw_text)
    if not match:
        for ab_match in _ENTRY_AB_VALUE_RE.finditer(raw_text):
            qual = str(ab_match.groupdict().get("qual") or "").lower()
            label = str(ab_match.groupdict().get("label") or ab_match.groupdict().get("label_paren") or "").lower()
            if label not in ("b", "\u0431"):
                continue
            if not _contains_any(qual, ("\u0443\u0441\u0440\u0435\u0434", "\u0434\u043e\u0431\u043e\u0440", "averag", "top up")):
                continue
            value = _to_float(str(ab_match.group("value")))
            if value is not None:
                return value
        for fallback_match in re.finditer(
            r"(?:^|\n)[^\n]*?\b(?P<label>b)\b(?P<tail>[^\n:]*)[:=@-]\s*(?P<value>\d[\d\s]*(?:[.,]\d+)?)",
            raw_text,
            re.IGNORECASE,
        ):
            tail = str(fallback_match.groupdict().get("tail") or "").lower()
            if not _contains_any(tail, ("\u0443\u0441\u0440\u0435\u0434", "\u0434\u043e\u0431\u043e\u0440", "averag", "top up")):
                continue
            value = _to_float(str(fallback_match.group("value")))
            if value is not None:
                return value
        return None
    return _to_float(match.group("value"))


def _to_float(raw: str) -> float | None:
    cleaned = raw.replace(" ", "")
    if "," in cleaned and "." not in cleaned:
        cleaned = cleaned.replace(",", ".")
    else:
        cleaned = cleaned.replace(",", "")
    try:
        return float(cleaned)
    except ValueError:
        return None
